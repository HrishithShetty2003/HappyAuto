from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from typing import Dict

from app.services.auth_service import AuthService
from app.core.database import get_db
from pydantic import BaseModel, EmailStr, validator

router = APIRouter(tags=["authentication"])#prefix="/auth"
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

# Pydantic Models
class UserRegister(BaseModel):
    name: str
    email: EmailStr
    phone: str
    password: str
    user_type: str
    
    @validator('user_type')
    def validate_user_type(cls, v):
        if v not in ['driver', 'customer']:
            raise ValueError('user_type must be driver or customer')
        return v
    
    @validator('phone')
    def validate_phone(cls, v):
        if not v.isdigit() or len(v) != 10:
            raise ValueError('Phone must be 10 digits')
        return v
    
    @validator('password')
    def validate_password(cls, v):
        if len(v) < 6:
            raise ValueError('Password must be at least 6 characters')
        return v

class UserLogin(BaseModel):
    email: EmailStr
    password: str

@router.post("/register", response_model=Dict)
async def register(user_data: UserRegister, db: Session = Depends(get_db)):
    """Register a new user"""
    result, error = AuthService.register_user(db, user_data.dict())
    
    if error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=error
        )
    
    return {
        "success": True,
        "message": "User registered successfully",
        **result
    }

@router.post("/login", response_model=Dict)
async def login(credentials: UserLogin, db: Session = Depends(get_db)):
    """Login user"""
    result, error = AuthService.login_user(
        db, 
        credentials.email, 
        credentials.password
    )
    
    if error:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=error
        )
    
    return {
        "success": True,
        "message": "Login successful",
        **result
    }

@router.get("/me", response_model=Dict)
async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
):
    """Get current user"""
    user, error = AuthService.get_current_user(db, token)
    
    if error:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=error
        )
    
    return {
        "id": user.id,
        "name": user.name,
        "email": user.email,
        "phone": user.phone,
        "user_type": user.user_type,
        "is_active": user.is_active,
        "created_at": user.created_at.isoformat() if user.created_at else None
    }