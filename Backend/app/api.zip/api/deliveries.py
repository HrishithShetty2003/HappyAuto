# # File: app/api/deliveries.py
# from fastapi import APIRouter, Depends, HTTPException, status
# from fastapi.security import OAuth2PasswordBearer
# from sqlalchemy.orm import Session
# from typing import List
# from app.schemas.delivery import DeliveryCreate, DeliveryResponse
# from app.services.delivery_service import DeliveryService
# from app.core.database import get_db
# from app.services.auth_service import AuthService
# from app.models.user import User

# router = APIRouter( tags=["deliveries"])#prefix="/deliveries",
# oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

# # def get_current_user_dep():
# #     return {"id": "demo_user"}

# def get_current_user_dep(
#     db: Session = Depends(get_db),
#     token: str = Depends(oauth2_scheme)
# ) -> User:
#     user, error = AuthService.get_current_user(db, token)

#     if error or not user:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="Invalid or expired token"
#         )

#     return user



# @router.post("/book", response_model=DeliveryResponse)
# async def book_delivery(
#     delivery_data: DeliveryCreate,
#     db: Session = Depends(get_db),
#     current_user: User = Depends(get_current_user_dep)
# ):
#     """Book a new car delivery"""
#     if current_user.user_type != "customer":
#         raise HTTPException(
#             status_code=status.HTTP_403_FORBIDDEN,
#             detail="Only customers can book deliveries"
#         )
    
#     delivery, error = DeliveryService.book_delivery(db, current_user.id, delivery_data.dict())
    
#     if error:
#         raise HTTPException(
#             status_code=status.HTTP_400_BAD_REQUEST,
#             detail=error
#         )
    
#     return delivery

# @router.get("/my-deliveries", response_model=List[DeliveryResponse])
# async def get_my_deliveries(
#     db: Session = Depends(get_db),
#     current_user: User = Depends(get_current_user_dep)
# ):
#     """Get user's deliveries"""
#     deliveries = DeliveryService.get_user_deliveries(db, current_user.id, current_user.user_type)
#     return deliveries

# @router.get("/{delivery_id}", response_model=DeliveryResponse)
# async def get_delivery(
#     delivery_id: str,
#     db: Session = Depends(get_db),
#     current_user: User = Depends(get_current_user_dep)
# ):
#     """Get specific delivery details"""
#     delivery = DeliveryService.get_delivery_by_id(db, delivery_id, current_user.id)
    
#     if not delivery:
#         raise HTTPException(
#             status_code=status.HTTP_404_NOT_FOUND,
#             detail="Delivery not found"
#         )
    
#     return delivery
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from typing import List

from app.schemas.delivery import DeliveryCreate, DeliveryResponse
from app.services.delivery_service import DeliveryService
from app.core.database import get_db
from app.services.auth_service import AuthService
from app.models.user import User
from app.models.delivery import Delivery  # ✅ needed for driver flow

router = APIRouter(tags=["deliveries"])
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


# -------------------------
# AUTH DEPENDENCY
# -------------------------
def get_current_user_dep(
    db: Session = Depends(get_db),
    token: str = Depends(oauth2_scheme)
) -> User:
    user, error = AuthService.get_current_user(db, token)

    if error or not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token"
        )

    return user


# -------------------------
# CUSTOMER: BOOK DELIVERY
# -------------------------
@router.post("/book", response_model=DeliveryResponse)
async def book_delivery(
    delivery_data: DeliveryCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """Book a new car delivery"""
    if current_user.user_type != "customer":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only customers can book deliveries"
        )

    delivery, error = DeliveryService.book_delivery(
        db,
        current_user.id,
        delivery_data.dict()
    )

    if error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=error
        )

    return delivery


# -------------------------
# CUSTOMER / DRIVER: MY DELIVERIES
# -------------------------
@router.get("/my-deliveries", response_model=List[DeliveryResponse])
async def get_my_deliveries(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """Get user's deliveries"""
    deliveries = DeliveryService.get_user_deliveries(
        db,
        current_user.id,
        current_user.user_type
    )
    return deliveries


# -------------------------
# CUSTOMER / DRIVER: GET DELIVERY BY ID
# -------------------------



# =========================================================
# 🚚 DRIVER FLOW (NEW)
# =========================================================

# -------------------------
# DRIVER: VIEW UNASSIGNED DELIVERIES
# -------------------------
@router.get("/unassigned", response_model=List[DeliveryResponse])
async def get_unassigned_deliveries(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """Get all unassigned deliveries (drivers only)"""
    if current_user.user_type != "driver":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Drivers only"
        )

    deliveries = (
        db.query(Delivery)
        .filter(
            Delivery.driver_id.is_(None),
            Delivery.status == "pending"
        )
        .all()
    )

    return deliveries


# -------------------------
# DRIVER: ACCEPT DELIVERY
# -------------------------
@router.post("/{delivery_id}/accept", response_model=DeliveryResponse)
async def accept_delivery(
    delivery_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """Driver accepts a delivery"""
    if current_user.user_type != "driver":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Drivers only"
        )

    delivery = (
        db.query(Delivery)
        .filter(Delivery.id == delivery_id)
        .first()
    )

    if not delivery:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Delivery not found"
        )

    if delivery.driver_id is not None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Delivery already assigned"
        )

    delivery.driver_id = current_user.id
    delivery.status = "assigned"

    db.commit()
    db.refresh(delivery)

    return delivery

@router.get("/{delivery_id}", response_model=DeliveryResponse)
async def get_delivery(
    delivery_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user_dep)
):
    """Get specific delivery details"""
    delivery = DeliveryService.get_delivery_by_id(
        db,
        delivery_id,
        current_user.id
    )

    if not delivery:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Delivery not found"
        )

    return delivery
