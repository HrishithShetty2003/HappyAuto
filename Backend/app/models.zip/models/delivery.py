# File: app/models/delivery.py
from sqlalchemy import Column, String, Float, Integer, DateTime, ForeignKey, Enum
from sqlalchemy.sql import func
import enum
from app.core.database import Base

class DeliveryStatus(str, enum.Enum):
    PENDING = "pending"
    ASSIGNED = "assigned"
    PICKED_UP = "picked_up"
    IN_TRANSIT = "in_transit"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"

class Delivery(Base):
    __tablename__ = "deliveries"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    customer_id = Column(String(36), ForeignKey('customers.id'))
    driver_id = Column(String(36), ForeignKey('drivers.id'), nullable=True)
    
    # Pickup details
    pickup_address = Column(String(500), nullable=False)
    pickup_lat = Column(Float, nullable=False)
    pickup_lng = Column(Float, nullable=False)
    
    # Dropoff details
    dropoff_address = Column(String(500), nullable=False)
    dropoff_lat = Column(Float, nullable=False)
    dropoff_lng = Column(Float, nullable=False)
    
    # Vehicle details
    vehicle_make = Column(String(100))
    vehicle_model = Column(String(100))
    vehicle_year = Column(Integer)
    vehicle_vin = Column(String(50), unique=True)
    
    # Delivery details
    status = Column(String(20), default=DeliveryStatus.PENDING.value)
    estimated_distance = Column(Float)  # in km
    estimated_time = Column(Float)      # in minutes
    estimated_cost = Column(Float)
    actual_distance = Column(Float)
    actual_time = Column(Float)
    actual_cost = Column(Float)
    
    # AI predictions
    suggested_driver_id = Column(String(36), ForeignKey('drivers.id'), nullable=True)
    optimal_route = Column(String)  # JSON encoded route
    predicted_traffic = Column(String(50))
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    scheduled_pickup = Column(DateTime(timezone=True))
    actual_pickup = Column(DateTime(timezone=True))
    actual_delivery = Column(DateTime(timezone=True))
    
    def __repr__(self):
        return f"<Delivery {self.id} - {self.status}>"